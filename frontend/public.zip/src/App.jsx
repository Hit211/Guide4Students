
import { Route, BrowserRouter as Router, Routes } from 'react-router'
import Intro from './pages/Intro'
import Dashboard from './pages/Dashboard/Dashboard'
import Roadmap from './pages/Dashboard/Roadmap'
import Development from './pages/Development/Development'
import Advice from './pages/Dashboard/Advice'
import News from './pages/Dashboard/News'
import Signup from './pages/SignUp'
import Login from './pages/Login'
import { Toaster } from 'sonner'
import Community from './pages/Community/Community'
const App = () => {
  return (
    <Router>
       <Routes>
        <Route path='/' element={<Intro/>}/>
        <Route path="/signup" element={<Signup/>}/>
        <Route path="/signin" element={<Login/>}/>
        <Route path="/dashboard" element={<Dashboard/>} />
        <Route path="/dashboard/roadmap" element={<Roadmap/>} />
        <Route path="/roadmap/:id" element={<Development/>}/>
        <Route path="/dashboard/advice" element={<Advice/>}/>
        <Route path="/dashboard/news" element={<News/>}/>
        <Route path="/dashboard/community" element={<Community/>}/>
       </Routes>
       <Toaster position='top-right' richColors/>
    </Router>
  )
}

export default App